import logo from "./logo.svg";
import "./App.css";
import SearchBox from "./component/SearchBox";
import List from "./component/List";
import userList from "./config/data";
import { React, useState, useEffect } from "react";

function App() {
  const [right, setRight] = useState([{}]);
  const [left, setLeft] = useState(userList);
  const handelLeftUpdates = (id) => {
    const selectedUser = userList.filter((x) => x.id == id);
    // console.log("which one is slected", selectedUser);
    setRight((prev) => [...prev, ...selectedUser]);
    // console.log("coming on Parent left...", id);
  };
  const handelRightUpdates = (id) => {
    const selectedUser = right.filter((x) => x.id !== id);
    setRight([...selectedUser]);
    console.log("coming on Parent right...", id);
  };
  const handelSearch = (query) => {
    // console.log("in the handelSearch", query);
    let res;
    if (query.length !== 0 || query !== "") {
      console.log("inside the query Loop", query);
      const res = left.filter((obj) =>
        Object.values(obj).some((val) => val.includes(query))
      );
      setLeft(res);
    } else {
      setLeft(userList);
    }
  };
  return (
    <div className="App">
      <SearchBox onSearch={handelSearch} />
      <div className="list-container">
        <List key={"left"} userList={left} onCustomClick={handelLeftUpdates} />
        <List
          key={"right"}
          onCustomClick={handelRightUpdates}
          userList={right}
        />
      </div>
    </div>
  );
}

export default App;
