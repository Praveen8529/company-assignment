import { React, useState, useEffect } from "react";

const SearchBox = ({ onSearch }) => {
  const [query, setQuery] = useState("");

  const handelClear = () => {
    onSearch("");
    setQuery("");
  };
  useEffect(() => {
    const debouncedSearch = setTimeout(() => {
      console.log("seaarching a Query for", query);
    }, 500);
    return () => {
      clearTimeout(debouncedSearch);
    };
  }, [query]);
  const handelQueryChange = (e) => {
    setQuery(e.target.value);
    onSearch(e.target.value);
  };
  return (
    <>
      <section>
        <label>Search names</label>
        <input type="text" value={query} onChange={handelQueryChange} />
        <button onClick={handelClear}>clear</button>
      </section>
    </>
  );
};

export default SearchBox;

const debouncer = () => {};
