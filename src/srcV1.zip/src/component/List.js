import { React, useState, useEffect } from "react";

const List = ({ userList = [], onCustomClick }) => {
  const handelSelection = (e) => {
    if (onCustomClick) {
      onCustomClick(e.target.id);
    }
  };
  console.log(userList);
  return (
    <>
      <section>
        <div className="list-container">
          <ul>
            {userList &&
              userList.length > 1 &&
              userList.map((item) => (
                <div>
                  <li key={item.id} id={item.id} onClick={handelSelection}>
                    {item.email} {item.name}
                  </li>
                </div>
              ))}
          </ul>
        </div>
      </section>
    </>
  );
};

export default List;
