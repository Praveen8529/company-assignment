const userList = [
  {
    id: "1",
    email: "kimberly_williams8898@bauros.biz",
    name: "Kimberly Williams",
  },
  {
    id: "2",
    email: "marvin_glass7458@bungar.biz",
    name: "Marvin Glass",
  },
  {
    id: "3",
    email: "makenzie_penn5606@brety.org",
    name: "Makenzie Penn",
  },
  {
    id: "4",
    email: "clint_slater3380@zorer.org",
    name: "Clint Slater",
  },
  {
    id: "5",
    email: "kamila_woodcock4041@gmail.com",
    name: "Kamila Woodcock",
  },
  {
    id: "6",
    email: "leilani_rodwell1908@womeona.net",
    name: "Leilani Rodwell",
  },
  {
    id: "7",
    email: "ron_davies2810@bauros.biz",
    name: "Ron Davies",
  },
  {
    id: "8",
    email: "russel_benfield6374@tonsy.org",
    name: "Russel Benfield",
  },
  {
    id: "9",
    email: "rick_irwin4949@hourpy.biz",
    name: "Rick Irwin",
  },
  {
    id: "10",
    email: "candace_poulton3766@gompie.com",
    name: "Candace Poulton",
  },
  {
    id: "11",
    email: "george_knott9500@ubusive.com",
    name: "George Knott",
  },
  {
    id: "12",
    email: "jacob_king5232@bulaffy.com",
    name: "Jacob King",
  },
  {
    id: "13",
    email: "gabriel_lane2117@elnee.tech",
    name: "Gabriel Lane",
  },
  {
    id: "14",
    email: "nicholas_uttley8062@bungar.biz",
    name: "Nicholas Uttley",
  },
  {
    id: "15",
    email: "mike_burge1490@nickia.com",
    name: "Mike Burge",
  },
  {
    id: "16",
    email: "karen_grady5703@infotech44.tech",
    name: "Karen Grady",
  },
  {
    id: "17",
    email: "cedrick_davies6266@ovock.tech",
    name: "Cedrick Davies",
  },
  {
    id: "18",
    email: "mark_rigg9430@bauros.biz",
    name: "Mark Rigg",
  },
  {
    id: "19",
    email: "bryon_craig7365@bulaffy.com",
    name: "Bryon Craig",
  },
  {
    id: "20",
    email: "boris_norton709@yahoo.com",
    name: "Boris Norton",
  },
];

export default userList;
